window.addEventListener("load", pageLoaded);

function pageLoaded() {

 // find the <g> in #textlines to use as a template
 
 // make a clone
 
 // modify the clone
 
 // position the clone

 // append it to the end of #textlines

}